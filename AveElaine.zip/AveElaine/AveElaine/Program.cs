﻿using System;
using System.Globalization;

namespace AveElaine
{
    class Program
    {
        private static BankService bankService = new BankService();

        public static void Main()
        {
            while (true)
            {
                Console.WriteLine("Welcome to AwesomeGIC Bank! What would you like to do?");
                Console.WriteLine("[T] Input transactions");
                Console.WriteLine("[I] Define interest rules");
                Console.WriteLine("[P] Print statement");
                Console.WriteLine("[Q] Quit");

                var choice = Console.ReadLine().ToUpper();
                if (choice == "Q") break;

                switch (choice)
                {
                    case "T":
                        InputTransactions();
                        break;
                    case "I":
                        DefineInterestRule();
                        break;
                    case "P":
                        PrintStatement();
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }

            Console.WriteLine("Thank you for banking with AwesomeGIC Bank. Have a nice day!");
        }

        private static void InputTransactions()
        {
            Console.WriteLine("Please enter transaction details in <Date> <Account> <Type> <Amount> format:");
            var input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input)) return;

            var parts = input.Split(' ');
            if (parts.Length != 4)
            {
                Console.WriteLine("Invalid format. Please try again.");
                return;
            }

            var dateString = parts[0];
            var accountId = parts[1];
            var type = char.ToUpper(parts[2][0]);
            if (!decimal.TryParse(parts[3], out var amount) || amount <= 0)
            {
                Console.WriteLine("Amount must be greater than zero.");
                return;
            }

            try
            {
                bankService.ProcessTransaction(dateString, accountId, type, amount);
                DisplayAccountStatement(accountId);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        private static void DefineInterestRule()
        {
            Console.WriteLine("Please enter interest rules details in <Date> <RuleId> <Rate in %> format:");
            var input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input)) return;

            var parts = input.Split(' ');
            if (parts.Length != 3)
            {
                Console.WriteLine("Invalid format. Please try again.");
                return;
            }

            var dateString = parts[0];
            var ruleId = parts[1];
            if (!decimal.TryParse(parts[2], out var rate) || rate <= 0 || rate >= 100)
            {
                Console.WriteLine("Rate must be between 0 and 100.");
                return;
            }

            try
            {
                bankService.DefineInterestRule(dateString, ruleId, rate);
                DisplayInterestRules();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        private static void PrintStatement()
        {
            Console.WriteLine("Please enter account and month to generate the statement <Account> <Year><Month>:");
            var input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input)) return;

            var parts = input.Split(' ');
            if (parts.Length != 2)
            {
                Console.WriteLine("Invalid format. Please try again.");
                return;
            }

            var accountId = parts[0];
            var period = parts[1];

            // Logic to print the statement for the given account and month
            // Implement interest calculation logic 
        }

        private static void DisplayAccountStatement(string accountId)
        {
            var transactions = bankService.GetAccountTransactions(accountId);
            Console.WriteLine($"Account: {accountId}");
            Console.WriteLine("| Date     | Txn Id      | Type | Amount |");
            foreach (var txn in transactions)
            {
                Console.WriteLine($"| {txn.Date:yyyyMMdd} | {txn.Id} | {txn.Type} | {txn.Amount:F2} |");
            }
        }

        private static void DisplayInterestRules()
        {
            var rules = bankService.GetInterestRules();
            Console.WriteLine("Interest rules:");
            Console.WriteLine("| Date     | RuleId | Rate (%) |");
            foreach (var rule in rules)
            {
                Console.WriteLine($"| {rule.Date:yyyyMMdd} | {rule.RuleId} | {rule.Rate:F2} |");
            }
        }
    }
}

