﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AveElaine
{
    public class BankService
    {
        private readonly Dictionary<string, Account> accounts = new Dictionary<string, Account>();
        private readonly List<InterestRule> interestRules = new List<InterestRule>();

        public void ProcessTransaction(string dateString, string accountId, char type, decimal amount)
        {
            DateTime date = DateTime.ParseExact(dateString, "yyyyMMdd", null);

            if (!accounts.ContainsKey(accountId))
            {
                accounts[accountId] = new Account(accountId);
            }

            if (type == 'D')
            {
                accounts[accountId].Deposit(amount);
            }
            else if (type == 'W')
            {
                accounts[accountId].Withdraw(amount);
            }
        }

        public void DefineInterestRule(string dateString, string ruleId, decimal rate)
        {
            DateTime date = DateTime.ParseExact(dateString, "yyyyMMdd", null);
            var rule = new InterestRule(date, ruleId, rate);

            var existingRule = interestRules.FirstOrDefault(r => r.Date == date);
            if (existingRule != null)
            {
                interestRules.Remove(existingRule);
            }

            interestRules.Add(rule);
        }

        public IEnumerable<Transaction> GetAccountTransactions(string accountId) =>
            accounts.ContainsKey(accountId) ? accounts[accountId].GetTransactions() : Enumerable.Empty<Transaction>();

        public List<InterestRule> GetInterestRules() => interestRules.OrderBy(r => r.Date).ToList();
    }
}
