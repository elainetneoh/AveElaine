﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AveElaine
{
    public class Account
    {
        public string Id { get; private set; }
        private decimal Balance { get; set; }
        private List<Transaction> Transactions { get; set; }

        public Account(string id)
        {
            Id = id;
            Balance = 0;
            Transactions = new List<Transaction>();
        }

        public void Deposit(decimal amount)
        {
            Balance += amount;
            var transaction = new Transaction(DateTime.Now, Id, 'D', amount, GenerateTransactionId());
            Transactions.Add(transaction);
        }

        public void Withdraw(decimal amount)
        {
            if (Balance < amount) throw new InvalidOperationException("Insufficient funds.");
            Balance -= amount;
            var transaction = new Transaction(DateTime.Now, Id, 'W', amount, GenerateTransactionId());
            Transactions.Add(transaction);
        }

        public IEnumerable<Transaction> GetTransactions() => Transactions;

        public decimal GetBalance() => Balance;

        private string GenerateTransactionId()
        {
            return $"{DateTime.Now:yyyyMMdd}-{Transactions.Count + 1:D2}";
        }
    }
}
