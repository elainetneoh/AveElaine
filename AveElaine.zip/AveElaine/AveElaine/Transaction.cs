﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AveElaine
{
    public class Transaction
    {
        public string Id { get; private set; }
        public DateTime Date { get; private set; }
        public string Account { get; private set; }
        public char Type { get; private set; } // 'D' for deposit, 'W' for withdrawal
        public decimal Amount { get; private set; }

        public Transaction(DateTime date, string account, char type, decimal amount, string id)
        {
            if (amount <= 0) throw new ArgumentException("Amount must be greater than zero.");
            if (type != 'D' && type != 'W') throw new ArgumentException("Type must be 'D' or 'W'.");

            Date = date;
            Account = account;
            Type = type;
            Amount = amount;
            Id = id;
        }
    }
}
